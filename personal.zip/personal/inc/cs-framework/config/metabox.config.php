<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();


// -----------------------------------------
// Post Metabox Options                    -
// -----------------------------------------
$options[]    = array(
  'id'        => 'personal_custom_post_options',
  'title'     => 'Services Post Options',
  'post_type' => 'service',
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'personl_post_section_1',
      'fields' => array(

        array(
          'id'    => 'sub_title',
          'type'  => 'text',
          'title' => 'Sub Title',
          'desc' => 'Type your sub title/catagoury',
        ),
        array(
          'id'    => 'link_text',
          'type'  => 'text',
          'title' => 'Link text',
          'desc' => 'Type your link text',
        ),
        array(
          'id'    => 'link',
          'type'  => 'text',
          'title' => 'Link',
          'desc' => 'Type your link ',
        ),
        array(
          'id'        => 'informations',
          'type'      => 'group',
          'title'     => 'Services Inormantions',
          'button_title'     => 'Add New',
          'accordion_title'     => 'Add New Information',
          'fields'    => array(
            array(
              'id'    => 'title',
              'type'  => 'text',
              'title' => 'Information',
            ),
            array(
              'id'    => 'value',
              'type'  => 'text',
              'title' => 'Informantion Value',
            ),
          ),
        ),

      ),
    ),

  ),
);

CSFramework_Metabox::instance( $options );

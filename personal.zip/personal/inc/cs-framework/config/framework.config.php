<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================



// ----------------------------------------
// Framework
// ----------------------------------------

$settings           = array(
  'menu_title'      => 'Theme Options',
  'menu_type'       => 'theme', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'personal_theme_options',
  'ajax_save'       => false,
  'show_reset_all'  => false,
  'framework_title' => 'Personal Theme <small>by Robiul Islam</small>',
);

$options        = array();


// ----------------------------------------
// Home page Options  -
// ----------------------------------------


$options[]      = array(
  'name'        => 'banner_1',
  'title'       => 'Home page Options',
  'icon'        => 'fa fa-star',

  // begin: fields
  'fields'      => array(
  

  /*========================
      Banner Options
  ==========================*/


    // begin: a field
    array(
      'id'      => 'banner_1_title',
      'type'    => 'text',
      'title'   => 'Type your Banner 1 Title',
      'desc'   => 'Type your banner 1 Title',
      'default'   => 'Philip Gilbert',
    ),
    array(
      'id'      => 'banner_1_subtitle',
      'type'    => 'text',
      'title'   => 'Type your Banner 1 Sub Title',
      'desc'   => 'Type your banner 1 Sub Title',
      'default'   => 'This is me',
    ),
    array(
      'id'      => 'banner_1_text',
      'type'    => 'textarea',
      'title'   => 'Type your Banner 1 Text',
      'default'   => 'You will begin to realise why this exercise is called the Dickens Pattern with reference to the ghost showing Scrooge some different futures.', 
    ),
    array(
      'id'      => 'banner_1_img',
      'type'    => 'image',
      'title'   => 'Banner 1 Image ',
    ),
    // end: a field

/*==================================================
      This is services options
==================================================*/

    // begin: a field
    array(
      'id'      => 'survices_title',
      'type'    => 'text',
      'title'   => 'Services Title',
      'desc'   => 'Type your Services Title',
      'default'   => 'My Offered Services',
    ),
    array(
      'id'      => 'survices_text',
      'type'    => 'textarea',
      'title'   => 'Services Text',
      'desc'   => 'Type your Services Text',
      'default'   => 'At about this time of year, some months after New Year’s resolutions have been made and kept, or made and neglected.',
    ),
    // end: a field

    // begin: a field
    array(
      'id'      => 'protfolio_title',
      'type'    => 'text',
      'title'   => 'Protfolio Title',
      'desc'   => 'Type your Protfolio Title',
      'default'   => 'Our Latest Featured Projects',
    ),
    array(
      'id'      => 'protfolio_text',
      'type'    => 'textarea',
      'title'   => 'Protfolio Text',
      'desc'   => 'Type your Protfolio Text',
      'default'   => 'Who are in extremely love with eco friendly system.',
    ),
    // end: a field


/*==================================================
      This is Testimonials options
==================================================*/

    // begin: a field
    array(
      'id'      => 'testimonial_title',
      'type'    => 'text',
      'title'   => 'Testimonial Title',
      'desc'   => 'Type your Testimonial Title',
      'default'   => 'Client’s Feedback About Me',
    ),
    array(
      'id'      => 'testimonial_text',
      'type'    => 'textarea',
      'title'   => 'Testimonial Text',
      'desc'   => 'Type your Testimonial Text',
      'default'   => 'It is very easy to start smoking but it is an uphill task to quit it. Ask any chain smoker or even a person.',
    ),
    // end: a field


/*==================================================
      This is prices options
==================================================*/

    // begin: a field
    array(
      'id'      => 'prices_title',
      'type'    => 'text',
      'title'   => 'Prices Title',
      'desc'   => 'Type your Prices Title',
      'default'   => 'Choose Your Plan',
    ),
    array(
      'id'      => 'prices_text',
      'type'    => 'textarea',
      'title'   => 'Prices Text',
      'desc'   => 'Type your Prices Text',
      'default'   => 'When someone does something that they know that they shouldn’t do, did they',
    ),
    // end: a field


/*==================================================
      This is Blog options
==================================================*/


    // begin: a field
    array(
      'id'      => 'blog_post_title',
      'type'    => 'text',
      'title'   => 'Blog post Title',
      'desc'   => 'Type your Blog  Title',
      'default'   => 'Latest posts from our blog',
    ),
    array(
      'id'      => 'blog_post_text',
      'type'    => 'textarea',
      'title'   => 'Blog Post Text',
      'desc'   => 'Type your Blog  Text',
      'default'   => 'You may be a skillful, effective employer but if you don’t trust your personnel and the opposite, then the chances of improving and expanding the business .',
    ),
    // end: a field
 ), // end: fields
);



/*======================================================
              ABOUT AREA
=======================================================*/

$options[]      = array(
  'name'        => 'about',
  'title'       => 'About page Options',
  'icon'        => 'fa fa-star',

  // begin: fields
  'fields'      => array(
  
  



    // begin: a field
    array(
      'id'      => 'about_area_title',
      'type'    => 'text',
      'title'   => 'Type your About Area Title',
      'desc'   => 'Type your About Area Title',
      'default'   => 'Personal Details',
    ),
    array(
      'id'      => 'about_area_title_subtitle',
      'type'    => 'text',
      'title'   => 'Type your About Area Sub Title',
      'desc'   => 'Type your About Area Sub Title',
      'default'   => 'About Me',
    ),
    array(
      'id'      => 'about_area_title_text',
      'type'    => 'textarea',
      'title'   => 'Type your About Area Text',
      'default'   => 'Here, I focus on a range of items and features that we use in life without giving them a second thought. such as Coca Cola. Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. ', 
    ),
    array(
      'id'      => 'about_area_img',
      'type'    => 'image',
      'title'   => 'About Area Image ',
    ),
    array(
      'id'      => 'about_area_another_text',
      'type'    => 'textarea',
      'title'   => 'About Area Another Text ',
      'desc'   => 'Please type your another text ',
      'default'   => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
    ),
      // end: a field

/*===================================================
          This is the switter area
=====================================================
     array(
      'id'    => 'skill_enable',
      'type'  => 'switcher',
      'title' => 'Skill Enable',
      'desc' => 'If you want to remove the skill section.',
    ),
    array(
      'id'      => 'about_area_img',
      'type'    => 'image',
      'title'   => 'About Area Image ',
       'dependency' => array( 'skill_enable', '==', 'true' ),
    ),

===================================================================*/


 ), // end: fields
);


/*======================================================
              FAQ AREA
=======================================================*/

$options[]      = array(
  'name'        => 'faq',
  'title'       => 'FAQ Options',
  'icon'        => 'fa fa-star',

  // begin: fields
  'fields'      => array(

   array(
      'id'    => 'faq_enable',
      'type'  => 'switcher',
      'title' => 'FAQ Enable',
      'default' => true,
      'desc' => 'If you want to remove the FAQ section.',
    ),
     array(
      'id'    => 'faq_title',
      'type'  => 'text',
      'title' => 'FAQ Title',
      'desc' => 'Type FAQ Title',
      'default' => 'Frequently Asked Questions',
      'dependency' => array( 'faq_enable', '==', 'true' ),
    ),
  array(
      'id'    => 'faq_text',
      'type'  => 'textarea',
      'title' => 'FAQ text',
      'desc' => 'Type FAQ text',
      'default' => 'When someone does something that they know that they shouldn’t do, did they really have a choice. Maybe what I mean to say is did they really have a chance. You can take two people.',
      'dependency' => array( 'faq_enable', '==', 'true' ),

    ),

  array(
      'id'    => 'faq_options',
      'type'  => 'group',
      'title' => 'FAQ Options',
      'button_title' => 'Add New',
      'dependency' => array( 'faq_enable', '==', 'true' ),
      'fields'    => array(
            array(
              'id' => 'faq_options_title',
              'type' => 'text',
              'title' => 'FAQ options title',
              'desc' => 'Type FAQ options Title',
            ),
            array(
              'id' => 'faq_options_text',
              'type' => 'textarea',
              'title' => 'FAQ options Text',
              'desc' => 'Type FAQ options Text',
            ),
        ),
    ),

 ), // end: fields
);






/*======================================================
              GLobal 
=======================================================*/



$options[]      = array(
  'name'        => 'global',
  'title'       => 'Global Options',
  'icon'        => 'fa fa-star',

  // begin: fields
  'fields'      => array(

   array(
      'id'    => 'logos_enable',
      'type'  => 'switcher',
      'title' => 'Logos Enable',
      'default' => true,
      'desc' => 'If you want to remove the Logos section.',
    ),
    array(
      'id'  => 'logos',
      'type'  => 'gallery',
      'title'  => 'Company Logos',
      'help'  => 'Upload Company Logo here',
      'dependency' => array( 'logos_enable', '==', 'true' ),

    ),
  
  ), // end: fields
);
CSFramework::instance( $settings, $options );

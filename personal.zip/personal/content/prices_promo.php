
<?php 
$prices_title = cs_get_option('prices_title');

$prices_text = cs_get_option('prices_text');

?>


<!-- Start price Area -->
			<section class="price-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-70 col-lg-8">
							<div class="title text-center">
								<h1 class="mb-10"><?php echo $prices_title ?></h1>
								 <?php echo wpautop($prices_text);?>
							</div>
						</div>
					</div>					
					<div class="row">

						<?php
							global $post;
							$number = 0; 
							$args = array( 'posts_per_page' => 4, 'post_type'=> 'feature', 'orderby' => 'menu_order', 'order' => 'ASC' );
							$myposts = get_posts( $args );
							foreach( $myposts as $post ) : setup_postdata($post); ?>

							<?php 
							   $price_link= get_post_meta($post->ID, 'price_link', true);  
							   $price_text= get_post_meta($post->ID, 'price_text', true); 
							?>

						<div class="col-lg-3 col-md-6 single-price">
							<div class="top-part">
								<h1 class="package-no"><?php the_title(); ?></h1>
						<pre><?php wpautop( $br = true ) ?></pre>
								<?php the_content();?>
						<pre><?php wpautop( $br = true ) ?></pre>
								<a class="price-btn text-uppercase" href="<?php echo $price_link ?>"><?php echo $price_text ?></a>
						</div>
						</div>
							<?php endforeach; ?>	
					
				</div>	
			</section>
<!-- End price Area -->			
	
<?php 
$protfolio_title = cs_get_option('protfolio_title');
$protfolio_text = cs_get_option('protfolio_text');
?>



<!-- Start portfolio-area Area -->
            <section class="portfolio-area section-gap" id="portfolio">
                <div class="container">
		            <div class="row d-flex justify-content-center">
		                <div class="menu-content pb-70 col-lg-8">
		                    <div class="title text-center">
		                        <h1 class="mb-10"><?php echo $protfolio_title ?></h1>
		                        <?php echo wpautop($protfolio_text);?>
		                    </div>
		                </div>
		            </div>
                    

                    <div class="filters-content">
                        <div class="row">
           				 <?php
							global $post;
							$number = 0; 
							$args = array( 'posts_per_page' => 6, 'post_type'=> 'protfolio', 'orderby' => 'menu_order', 'order' => 'ASC' );
							$myposts = get_posts( $args );
							foreach( $myposts as $post ) : setup_postdata($post); ?>

                            <div class="single-portfolio col-sm-4">
                            	<div class="relative">
	                            	<div class="thumb">
	                            		<div class="overlay overlay-bg"></div>
	                            		  <?php the_post_thumbnail('large');?>
	                            	</div>                        		
                            	</div>
								<div class="p-inner">
								    <h4><?php the_title();?></h4>
									<?php echo get_post_meta($post->ID , 'sub_title',true);?>
								</div>					                               
                            </div>
	 
						<?php endforeach; ?>

							  


						</div>					                               
                      </div>
                  </div>
            </section>   
            <!-- End portfolio-area Area -->	
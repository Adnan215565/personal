<?php

$blog_post_title = cs_get_option('blog_post_title');
$blog_post_text = cs_get_option('blog_post_text');

?>


<!-- Start recent-blog Area -->
			<section class="recent-blog-area section-gap">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-md-8 pb-30 header-text">
							<h1><?php echo $blog_post_title ;?></h1>
							<?php echo wpautop($blog_post_text); ?>
						</div>
					</div>
					<div class="row">

						<?php
							global $post;
							$number = 0; 
							$args = array( 'posts_per_page' => 3, 'post_type'=> 'blog', 'orderby' => 'menu_order', 'order' => 'ASC' );
							$myposts = get_posts( $args );
							foreach( $myposts as $post ) : setup_postdata($post); ?>

						<div class="single-recent-blog col-lg-4 col-md-4">
							<div class="thumb">
								<?php the_post_thumbnail();?>
							</div>
							<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
								<div>
									<img class="img-fluid" src="<?php echo get_template_directory_uri();?>/assets/img/user.png" alt="">
									<a href="#"><span>

							<?php the_author( $deprecated = 'latest_post.php', $deprecated_echo = true ) ?>	
								</span></a>

								</div>
								<div class="meta">
									13th Dec
									<span class="lnr lnr-heart"></span> 15
									<span class="lnr lnr-bubble"></span> 04
								</div>
							</div>							
							<a href="#">
								<h4><?php the_title();?></h4>
							</a>
							<?php the_content();?>
						</div>
							 
							<?php endforeach; ?>			
												
					</div>
				</div>	
			</section>
			<!-- end recent-blog Area -->	
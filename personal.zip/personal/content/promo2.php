<?php 
$survices_title = cs_get_option('survices_title');

$survices_text = cs_get_option('survices_text');

?>

			<!-- Start services Area -->
			<section class="services-area section-gap">
				<div class="container">
		            <div class="row d-flex justify-content-center">
		                <div class="menu-content  col-lg-7">
		                    <div class="title text-center">
		                        <h1 class="mb-10"><?php echo $survices_title ?></h1>
		                        <?php echo wpautop($survices_text);?>
		                    </div>
		                </div>
		            </div>						
					<div class="row">
						<?php
							global $post;
							$args = array( 'posts_per_page' => 6, 'post_type'=> 'service', 'orderby' => 'menu_order', 'order' => 'ASC' );
							$myposts = get_posts( $args );
							foreach( $myposts as $post ) : setup_postdata($post); ?>
							 
							<?php 
							   $btn_link= get_post_meta($post->ID, 'btn_link', true); 
							?>
							<div class="col-lg-4 col-md-6">
								<div class="single-services">
									<span><img src="<?php echo the_post_thumbnail_url(); ?>"></span>
									<a href="<?php echo $btn_link ?>"><h4><?php the_title();?></h4></a>
									<?php the_content(); ?>
								</div>
							</div>

						<?php endforeach; wp_reset_query(); ?>						
					</div>
				</div>	
			</section>
			<!-- End services Area -->

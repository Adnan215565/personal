
<?php 
$testimonial_title = cs_get_option('testimonial_title');

$testimonial_text = cs_get_option('testimonial_text');

?>


<!-- Start testimonial Area -->
		    <section class="testimonial-area section-gap">
		        <div class="container">
		            <div class="row d-flex justify-content-center">
		                <div class="menu-content pb-70 col-lg-8">
		                    <div class="title text-center">
		                        <h1 class="mb-10"><?php echo $testimonial_title ?></h1>
		                        <?php echo wpautop($testimonial_text);?>
		                    </div>
		                </div>
		            </div>
		            <div class="row">
		                <div class="active-testimonial">
		                   
						<?php
							global $post;
							$number = 0; 
							$args = array( 'posts_per_page' => 5, 'post_type'=> 'slide', 'orderby' => 'menu_order', 'order' => 'ASC' );
							$myposts = get_posts( $args );
							foreach( $myposts as $post ) : setup_postdata($post); ?>


							  <div class="single-testimonial item d-flex flex-row">
							         <div class="thumb">
		                            <img class="img-fluid" src="<?php echo the_post_thumbnail_url( ); ?>">
		                        </div>
		                        <div class="desc">
		                            <h4><?php the_title(); ?> </h4>
		                           <?php the_content( ) ?>
		                        </div>
		                    </div>
							 
							<?php endforeach; ?>
		                </div>
		            </div>
		        </div>
		    </section>
		    <!-- End testimonial Area -->